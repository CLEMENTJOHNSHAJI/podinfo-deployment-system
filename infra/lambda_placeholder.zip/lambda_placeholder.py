def handler(event, context):
    return {
        'statusCode': 200,
        'body': '{"message": "Podinfo Lambda placeholder - waiting for container image"}'
    }
