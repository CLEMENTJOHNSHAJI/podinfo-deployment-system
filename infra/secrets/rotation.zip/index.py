import json
import boto3
import random
import string

def lambda_handler(event, context):
    """
    Rotate the application secret
    """
    secret_arn = event['SecretId']
    
    # Create a new secret value
    new_token = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
    
    # Update the secret
    secrets_client = boto3.client('secretsmanager')
    
    try:
        # Get current secret
        current_secret = secrets_client.get_secret_value(SecretId=secret_arn)
        current_value = json.loads(current_secret['SecretString'])
        
        # Update with new token
        current_value['SUPER_SECRET_TOKEN'] = new_token
        
        # Update the secret
        secrets_client.update_secret(
            SecretId=secret_arn,
            SecretString=json.dumps(current_value)
        )
        
        print(f"Successfully rotated secret {secret_arn}")
        return {"statusCode": 200, "body": "Secret rotated successfully"}
        
    except Exception as e:
        print(f"Error rotating secret: {str(e)}")
        raise e
